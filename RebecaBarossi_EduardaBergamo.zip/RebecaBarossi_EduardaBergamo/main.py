#Rebeca de Souza Barossi e Eduarda Cristina Bergamo

#importando modulos de biblioteca
from flask import Flask
from flask import render_template
from flask import request

#Iniciando aplicação
app = Flask(__name__)

#Criando a primeira rota
@app.route('/main/')
@app.route('/main/<name>')
def main (name=None):
    return render_template('main.html', person=name)

#Iniciando aplicativo
#Banco de dados simulado com um dicionário
# Estrutura de dados para armazenar os preços das diárias.

# Tabela de preços (valor DA DIÁRIA POR PESSOA)
TABELA_PRECOS = {
    1: {1: 20.00, 2: 28.00, 3: 35.00, 4: 42.00, 5: 48.00, 6: 53.00},
    2: {1: 25.00, 2: 34.00, 3: 42.00, 4: 50.00, 5: 57.00, 6: 63.00}
}

# página inteira (home + formulário)
@app.route('/')
def pagina_principal():
    """Renderiza a página 'main.html'."""
    return render_template('main.html')

# Rota que processa os dados do formulário de reserva
@app.route('/processar_reserva', methods=['POST'])
def processar_reserva():
    """
    Recebe os dados do formulário, valida as informações e, se tudo
    estiver correto, calcula o valor e exibe o resultado na mesma página.
    Caso contrário, exibe as mensagens de erro.
    """
    # Lista para armazenar as mensagens de erro
    erros = []

    #Coleta e validação dos dados
    nome = request.form.get('nome', '').strip()
    tipo_ap_str = request.form.get('tipo_apartamento')
    dias_str = request.form.get('dias')
    pessoas_str = request.form.get('pessoas')

    # Validação do Nome: não pode estar vazio e deve ser alfanumérico (com espaços)
    if not nome:
        erros.append("O campo 'Nome' é obrigatório.")
    # A verificação abaixo garante que o nome não contenha números ou caracteres especiais.
    # nome.replace(' ', ''): Remove todos os espaços do nome. "Ana Maria" vira "AnaMaria".
    # .isalpha(): Retorna 'True' APENAS se todos os caracteres restantes forem letras, (incluindo acentos como 'á', 'ç'). Se houver um número ('Ana123') ou um
    # símbolo ('Ana-Maria'), o resultado será 'False'.
    # not ...: Quero o erro quando for 'False', por isso o uso do 'not'.
    elif not nome.replace(' ', '').isalpha():
        erros.append("O campo 'Nome' deve conter apenas letras e espaços (sem números ou símbolos).")
    # Validação do Tipo de Apartamento
    if not tipo_ap_str:
        erros.append("Você deve selecionar um tipo de apartamento.")

    # Validação de Dias
    try:
        dias = int(dias_str)
        if not (1 <= dias <= 7):
            erros.append("A quantidade de dias deve ser entre 1 e 7.")
    except (ValueError, TypeError):
        erros.append("O valor para 'dias' deve ser um número inteiro.")

    # Validação de Pessoas
    try:
        pessoas = int(pessoas_str)
        if not (1 <= pessoas <= 6):
            erros.append("A quantidade de pessoas deve ser entre 1 e 6.")
    except (ValueError, TypeError):
        erros.append("O valor para 'pessoas' deve ser um número inteiro.")

    # Verificação final e cálculo
    # Se a lista de erros não estiver vazia, retorna para a página mostrando os erros e mantendo os dados que o usuário digitou.
    if erros:
        return render_template('main.html', erros=erros, form_data=request.form)

    # Se não houver erros, prossiga com o cálculo
    tipo_ap = int(tipo_ap_str)
    
     # O cálculo multiplica o valor por pessoa pelo número de pessoas e depois pelos dias.
    tipo_ap = int(tipo_ap_str)
    valor_diaria_por_pessoa = TABELA_PRECOS[tipo_ap][pessoas]
    valor_total = valor_diaria_por_pessoa * pessoas * dias

    #Renderiza a página novamente, agora com os resultados
    return render_template(
        'main.html',
        nome_cliente=nome,
        tipo_ap_cliente=tipo_ap,
        dias_cliente=dias,
        pessoas_cliente=pessoas,
        valor_total_calculado=f'{valor_total:.2f}'.replace('.',','), # Formata para R$ 0,00
        form_data=request.form # Mantém os dados no formulário
    )


if __name__ == '__main__':
    app.run(debug=True)


